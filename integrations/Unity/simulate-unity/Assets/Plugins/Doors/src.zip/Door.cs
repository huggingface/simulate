using Simulate;
using System.Collections.Generic;
using Newtonsoft.Json;

public class Door : IGLTFExtension {
    [JsonProperty("initial_state"), JsonConverter(typeof(EnumConverter))] public DoorAI.State initialState = DoorAI.State.Closed;
    [JsonProperty("closed_angle")] public float closedAngle = 0f;
    [JsonProperty("open_angle")] public float openAngle = 90f;
    [JsonProperty("animation_time")] public float animationTime = .5f;

    public void Initialize(Node node, Dictionary<string, object> kwargs) {
        DoorAI doorAI = node.gameObject.AddComponent<DoorAI>();
        doorAI.closedAngle = closedAngle;
        doorAI.openAngle = openAngle;
        doorAI.state = initialState;
        doorAI.animationTime = animationTime;
    }
}
