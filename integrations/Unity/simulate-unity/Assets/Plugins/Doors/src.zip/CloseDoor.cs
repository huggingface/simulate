using System.Collections.Generic;
using Simulate;
using UnityEngine.Events;

public class CloseDoor : ICommand {
    public string door;

    public void Execute(Dictionary<string, object> kwargs, UnityAction<string> callback) {
        DoorsPlugin.CloseDoor(door);
        callback("{}");
    }
}
