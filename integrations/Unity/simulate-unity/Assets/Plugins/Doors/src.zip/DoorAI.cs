using UnityEngine;
using Simulate;

public class DoorAI : MonoBehaviour {
    public State state { get; set; }
    public float closedAngle { get; set; }
    public float openAngle { get; set; }
    public float animationTime { get; set; }

    public enum State {
        Closed,
        Open,
        Opening,
        Closing
    }

    float t;

    void Awake() {
        t = 0;
        if (state == State.Closed)
            transform.rotation = Quaternion.Euler(0, closedAngle, 0);
        else
            transform.rotation = Quaternion.Euler(0, openAngle, 0);
    }

    public void Step() {
        switch (state) {
            case State.Opening:
                t = Mathf.Min(1, t + Config.instance.timeStep / animationTime);
                if (t == 1) {
                    state = State.Open;
                    return;
                }
                break;
            case State.Closing:
                t = Mathf.Max(0, t - Config.instance.timeStep / animationTime);
                if (t == 0) {
                    state = State.Closed;
                    return;
                }
                break;
        }
        transform.rotation = Quaternion.Euler(0, Mathf.Lerp(closedAngle, openAngle, t), 0);
    }

    public void Open() {
        state = State.Opening;
    }

    public void Close() {
        state = State.Closing;
    }
}